﻿using System.Linq;

namespace SAModelLibrary.IO
{
    public enum Endianness
    {
        Little,
        Big
    }
}
