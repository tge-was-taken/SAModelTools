﻿namespace SAModelLibrary.IO
{
    public enum StringBinaryFormat
    {
        Unknown,
        NullTerminated,
        FixedLength,
        PrefixedLength8,
        PrefixedLength16,
        PrefixedLength32,
    }
}
